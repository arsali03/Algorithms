import java.util.*;



        class Graf {
            int[][] graf;
            int[] desen;


            public Graf(int[][] graf) {
                this.graf = graf;
                desen = new int[graf.length];
            }

            // bu kısımda graf üzerinde gezinerek kaynaktan hedefe en kısa yolun var olup olmadığı kontrol edilir.
            public boolean bfs(int kaynak, int hedef) {
                boolean[] visited = new boolean[graf.length];
                Arrays.fill(visited, false);
                Queue<Integer> queue = new LinkedList<Integer>();
                queue.add(kaynak);
                visited[kaynak] = true;
                desen[kaynak] = -1;

                while (!queue.isEmpty()) {
                    int u = queue.poll();
                    for (int v = 0; v < graf.length; v++) {
                        if (!visited[v] && graf[u][v] > 0) {
                            queue.add(v);
                            desen[v] = u;
                            visited[v] = true;
                        }
                    }
                }

                return visited[hedef];
            }

            public int fordFulkerson(int kaynak, int hedef) {
                int maxAkis = 0;
                while (bfs(kaynak, hedef)) {
                    int akisYolu = Integer.MAX_VALUE;
                    for (int v = hedef; v != kaynak; v = desen[v]) {
                        int u = desen[v];
                        akisYolu = Math.min(akisYolu, graf[u][v]);
                    }
                    for (int v = hedef; v != kaynak; v = desen[v]) {
                        int u = desen[v];
                        graf[u][v] -= akisYolu;
                        graf[v][u] += akisYolu;
                    }
                    maxAkis += akisYolu;
                }
                return maxAkis;
            }
        }

public class Main {
    public static void main(String[] args) {
        int[][] graf = {
                {0, 16, 13, 0, 0, 0},
                {0, 0, 10, 12, 0, 0},
                {0, 4, 0, 0, 14, 0},
                {0, 0, 9, 0, 0, 20},
                {0, 0, 0, 7, 0, 4},
                {0, 0, 0, 0, 0, 0}
        };
        Graf g = new Graf(graf);
        System.out.println("Maksimum akış: " + g.fordFulkerson(0, 5));
    }
}
