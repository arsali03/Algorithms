import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

    // Shift Table oluşturuyoruz.
    public static int[] createShiftTable(String desen) {
        int[] shiftTable = new int[256];
        for (int i = 0; i < shiftTable.length; i++) {
            shiftTable[i] = desen.length();//
        }
        for (int i = 0; i < desen.length() - 1; i++) {
            shiftTable[desen.charAt(i)] = desen.length() - 1 - i;
        }
        return shiftTable;
    }

    // Bu metod aranen desenin metinde kaç defa geçtiğini sayar.
    public static int tekrarSayisi(String metin, String desen) {
        int[] shiftTable = createShiftTable(desen);
        int say = 0;
        int metinIndex = 0;
        while (metinIndex <= metin.length() - desen.length()) {
            int desenIndex = desen.length() - 1;
            while (desenIndex >= 0 && desen.charAt(desenIndex) == metin.charAt(metinIndex + desenIndex)) {
                desenIndex--;
            }
            if (desenIndex < 0) {
                say++;
                metinIndex += desen.length();
            } else {
                metinIndex += shiftTable[metin.charAt(metinIndex + desen.length() - 1)];
            }
        }
        return say;
    }

    public static void main(String[] args) {

        System.out.println("\nHorspool Algoritması ile Text İçinde Desen Bulma\n");


        boolean repeat = true;
        while (repeat) {

            Scanner scanner3 = new Scanner(System.in);
            Scanner scanner2 = new Scanner(System.in);

            // bu kısımda aranacak metin dosyasını tanımlıyoruz.
            System.out.print("Arama yapmak istediğiniz metin dosyasını klasöre atınız, daha sonra metin dosyasının adını giriniz: ");
            String sFile = scanner2.nextLine();

            String fileName = sFile+".txt";
            File file = new File(fileName);



            try {

                boolean repeat2 = true;
                while (repeat2) {
                    Scanner scanner4 = new Scanner(System.in);
                    Scanner scanner = new Scanner(file);
                    String content = "";

                    // burada metin içeriğini content denen değişkene atıyoruz.
                    while (scanner.hasNextLine()) {
                        content += scanner.nextLine() + "\n";}

                    String text = content;
                    Scanner scanner1 = new Scanner(System.in);
                    System.out.print("Aramak istenilen deseni giriniz: ");
                    String pattern = scanner1.nextLine();
                    scanner.close();

                    // bu kısımda desenin kaç kere geçtiğini bulacak metodu çağırıyoruz.
                    int say = tekrarSayisi(text, pattern);
                    if (say == 0) {
                        System.out.println("Aradığınız '" + pattern + "' deseni metinde bulunmuyor.");

                    } else {
                        System.out.println("Aradığınız '" + pattern + "' deseni metinde " + say + " kez tekrar ediyor.");
                    }

                    System.out.println("Tekrar denemek için 'E', programdan çıkmak için herhangi bir tuşa basın.");
                    String input = scanner4.next();
                    repeat2 = input.equalsIgnoreCase("E");
                }

            }
            catch (FileNotFoundException e) {
                System.out.println("Dosya bulunamadı: " + fileName);
                System.out.println("Tekrar denemek için 'E', programdan çıkmak için herhangi bir tuşa basın.");
                String input = scanner3.next();
                repeat = input.equalsIgnoreCase("E");

            }

            System.out.println("Tekrar denemek için 'E', programdan çıkmak için herhangi bir tuşa basın.");
            String input = scanner3.next();
            repeat = input.equalsIgnoreCase("E");





        }
        System.out.println("Program sonlandırıldı.");




    }
}
